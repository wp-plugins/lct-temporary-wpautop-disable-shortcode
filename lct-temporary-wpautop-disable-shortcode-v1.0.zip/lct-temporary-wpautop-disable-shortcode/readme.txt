=== LCT Temporary wpautop Disable Shortcode ===
Contributors: ircary
Donate link: http://lookclassy.com/
Tags: shortcode, disable wpautop
Requires at least: 3.0
Tested up to: 3.8
Stable tag: 1.0
License: GPLv3 or later
License URI: http://opensource.org/licenses/GPL-3.0

Use a simple shortcode to bypass the sometimes damaging effect of the wpautop function.


== Description ==
Use a simple shortcode to bypass the sometimes damaging effect of the wpautop function.

== Installation ==
1. Upload the zip file contents to your Wordpress plugins directory.
2. Go to the Plugins page in your WordPress Administration area and click 'Activate' for LCT Temporary wpautop Disable Shortcode.
3. Use this shortcode to disable wpautop for the content within [raw]Code you don't want filter by wpautop[/raw]

== Screenshots ==
none

== Frequently Asked Questions ==
none


== Upgrade Notice ==
none


== Changelog ==
= 1.0 =
	- First Release
